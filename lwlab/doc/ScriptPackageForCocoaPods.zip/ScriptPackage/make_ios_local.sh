#!/bin/sh
#自动打包脚本,xcode版本为:Xcode 8.3 Build version 8E162

#工程名称
projectName="ScriptPackage"
pwdDir=`pwd`
#xcode版本号是否>=8.3
xcodeVersion=`xcodebuild -version | grep -e "Xcode [\d\.]*" | sed 's/Xcode //'`
#比较两个版本号的大小关系,输入参数$1,$2,返回0=相等,1=$1>$2,2=$1<$2
function compareVersionNumber(){
	OLD_IFS=$IFS
	IFS='.'
	local v1=($1)
	local v2=($2)
	IFS=$OLD_IFS
	local len1=${#v1[@]}
	local len2=${#v2[@]}
	for((i=0;i<$len1;i++))
	do
		local num1=${v1[$i]}
		if [ $i -le $len2 ] ; then
			local num2=${v2[$i]}
			[ $num1 -gt $num2 ] && return 1
			[ $num1 -lt $num2 ] && return 2
		else
			return 1
		fi
	done
	[ $len1 -lt $len2 ] && return 2
	return 0
}
xcodeVersionGE8_3=0
compareVersionNumber $xcodeVersion "8.3"
[ $? -le 1 ] && xcodeVersionGE8_3=1

#工程所在目录
projectDir=$pwdDir
if [ ! -d $projectDir ] ; then
echo "$projectDir not exists,please cd to project dir"
exit 1
fi
#版本号
version="{VERSION}"
[ -n $1 ] && version=$1
#产品名,对应于工程配置的PRODUCT_NAME.这里要求PRODUCT_NAME不能含有空格
productName="${projectName}"
#target所在的scheme
scheme="$productName"
#证书所在的钥匙串,证书名称会在打包时从描述文件中获取
keychain=~/Library/Keychains/login.keychain
#钥匙串密码
keychainPwd="123"
exportOptionsPlist="$projectDir/$productName/exportOptions.plist"
echo $exportOptionsPlist
#临时的工作目录
date=`date +%Y%m%d_%H%M%S`
workspace="$projectDir/../ipa/${productName}_${version}_${date}"
[ ! -d "$workspace" ] && mkdir -p "$workspace"
#工程文件路径
project="$projectDir/$projectName.xcworkspace"

#1.解锁钥匙串
security unlock-keychain -p "$keychainPwd" "$keychain"
#设置搜索钥匙串
security list-keychains -s "$keychain"
cd "$projectDir" || exit 1;

logFile="$workspace/make_ios.log"
ipaDir=$workspace
ipaFile="$ipaDir/$productName.ipa"
archivePath="$workspace/$productName.xcarchive"
#ipa包所在的目录
ipaDstDir="$projectDir/../ipa"
#产生ipa文件
function genipa(){
	#2.清空
	echo 1>"$logFile"
	[ -f "$ipaFile" ] && rm "$ipaFile"
	xcodebuild clean -workspace "$project" -scheme "$scheme" -sdk "iphoneos" -configuration "release" 2>&1 | tee -a "$logFile"
	#3.使用archive打包
	xcodebuild archive -workspace "$project" -scheme "$scheme" -sdk "iphoneos" -configuration "release" -archivePath "$archivePath" OTHER_CODE_SIGN_FLAGS="--keychain=$keychain" 2>&1 | tee -a "$logFile"
	#4.导出ipa包
	#创建ipa的存放目录
#
	if [ $xcodeVersionGE8_3 -eq 1 ] ; then
		xcodebuild -exportArchive -project "$project" -archivePath "$archivePath" -exportPath "$ipaDir" -exportOptionsPlist "$exportOptionsPlist" 2>&1 | tee -a "$logFile"
	else
		xcodebuild -exportArchive -project "$project" -exportFormat "ipa" -archivePath "$archivePath" -exportPath "$ipaFile" 2>&1 | tee -a "$logFile"
	fi
}
genipa
#由于xcodebuild的bug,在exportArchive时,不会生成archived-expanded-entitlements.xcent这个文件,从而导致脚本打出的包不能安装.这里手动产生该文件,并重新进行代码签名
#该bug已经在xcode8.3被修复了
function genXCentFile(){
	#解压开ipa包
	cd "$workspace"
	zipDir="$workspace/tmp_zip"
	mkdir -p "$zipDir"
	unzip "$ipaFile" -d "$zipDir"
	#根据make_ios.log,解析出codesign时的参数
	codesignCmd=$(cat "$logFile"|grep "/usr/bin/codesign --force --sign")
	#codesignCmd=/usr/bin/codesign --force --sign 647A38E312021DCE7B295C98F29F59D13C0A1934 --keychain=/Users/moon/Library/Keychains/login.keychain --entitlements /Volumes/HV/Users/hvrd/moon/Xcode/DerivedData/hvlab-frryauhfdalrogefokmiitnmejwt/Build/Intermediates/ArchiveIntermediates/hvlab/IntermediateBuildFilesPath/hvlab.build/Release-iphoneos/hvlab.build/hvlab.app.xcent /Volumes/HV/Users/hvrd/moon/Xcode/DerivedData/hvlab-frryauhfdalrogefokmiitnmejwt/Build/Intermediates/ArchiveIntermediates/hvlab/InstallationBuildProductsLocation/Applications/hvlab.app
	cmdPice=($codesignCmd)
	entitlements=""
	entitlementsIndex=0
	cmdPiceLen=${#cmdPice[@]}
	for((i=0;i<$cmdPiceLen;i++))
	do
	item=${cmdPice[$i]}
	if [ $item = "--entitlements" ] ;then
	entitlementsIndex=$(($i+1))
	entitlements=${cmdPice[$entitlementsIndex]}
	break;
	fi
	done
	appDir="$zipDir/Payload/$productName.app"
	xcentFile="$appDir/archived-expanded-entitlements.xcent"
	cp "$entitlements" "$xcentFile"
	cmdPice[$cmdPiceLen-1]="$appDir"
	cmdPice[$entitlementsIndex]=$xcentFile
	codesignCmd2=${cmdPice[@]:0:$cmdPiceLen}
	echo $codesignCmd2
	`$codesignCmd2`
	#重新生成ipa压缩包
	#mv "$ipaFile" "$ipaDir/${productName}_bug.ipa"
	rm -rf "$ipaFile"
	cd "$zipDir"
	zip -r "$ipaFile" *
	rm -rf "$zipDir"
}
#xcode8.3之后,修改了genXCentFile的bug
[ $xcodeVersionGE8_3 -eq 0 ] && genXCentFile

[ ! -d "$ipaDstDir" ] && mkdir -p "$ipaDstDir"
#cp "$ipaFile" "$ipaDstDir/${productName}_${version}_${date}.ipa"
#cp -r "$archivePath" "$ipaDstDir/${productName}_${version}_${date}.xcarchive"
#cp一份到共同文件中
cp -f "$ipaFile" "$ipaDstDir/${productName}_${version}.ipa"
cp -rf "$archivePath" "$ipaDstDir/${productName}_${version}.xcarchive"
rm -rf "$workspace"
exit 0
