//___FILEHEADER___

#import "___FILEBASENAME___.h"
#import "___VARIABLE_productName:identifier___.h"

@implementation ___FILEBASENAMEASIDENTIFIER___
- (instancetype)init{
    if(self = [super init]){
        self.cellClass = [___VARIABLE_productName:identifier___ class];
    }
    return self;
}
@end
