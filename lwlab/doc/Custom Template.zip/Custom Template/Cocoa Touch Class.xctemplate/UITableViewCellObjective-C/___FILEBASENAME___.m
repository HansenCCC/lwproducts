//___FILEHEADER___

#import "___FILEBASENAME___.h"

@interface ___FILEBASENAMEASIDENTIFIER___ ()

@end

@implementation ___FILEBASENAMEASIDENTIFIER___
DEF_SINGLETON(___FILEBASENAMEASIDENTIFIER___);
-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]){
        self.contentView.backgroundColor = [UIColor colorWithRandomColor];
        self.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    return self;
}
#pragma mark- model
DEF_HVTableViewCellModel(___FILEBASENAMEASIDENTIFIER___Model, customCellModel);
- (void)setCustomCellModel:(___FILEBASENAMEASIDENTIFIER___Model *)customCellModel{
    _customCellModel = customCellModel;
    //
    [self layoutIfNeeded];
}
#pragma mark- layout
- (void)layoutSubviews{
    [super layoutSubviews];
    CGRect bounds = self.contentView.bounds;
    CGRect f1 = bounds;
}
//+(CGFloat)heightWithTableView:(UITableView *)tableView cellModel:(HVTableViewCellModel *)cellModel{
//    return 45;
//    CGFloat height = [LWTitleTableViewCell dynamicHeightWithTableView:tableView cellModel:cellModel cellShareInstance:[self.class sharedInstance] calBlock:^CGFloat(UITableView *tableView, HVTableViewCellModel *cellModel, id cell) {
//        LWTitleTableViewCell *_cell = cell;
//        return 100;
//    }];
//}
@end
