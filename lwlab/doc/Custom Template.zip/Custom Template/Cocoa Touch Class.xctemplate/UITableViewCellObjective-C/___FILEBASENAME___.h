//___FILEHEADER___

___IMPORTHEADER_cocoaTouchSubclass___
#import "___FILEBASENAME___Model.h"

@interface ___FILEBASENAMEASIDENTIFIER___ : ___VARIABLE_cocoaTouchSubclass___<HVTableViewCellProtocol>
AS_SINGLETON(___FILEBASENAMEASIDENTIFIER___);
@property(nonatomic,strong) ___FILEBASENAMEASIDENTIFIER___Model *customCellModel;
@end
